import numpy as np
import pandas as pd
from upsetplot import from_contents
import matplotlib.pyplot as plt
import upsetplot as usp
import os
import best_model
from astropy.io import fits
from astropy.time import Time
import glob
from ciao_contrib.runtool import *
from astropy import units as u
from astropy.coordinates import SkyCoord
import re
from get_abs_sherpa_bxa import *
from get_abs_sherpa_bxa_alt import *
from get_abs_sherpa_bxa_restricted import *
from os import path

#input into the process:
input_file=pd.read_csv('/Users/kciurleo/Documents/kciurleo/AGN/csvs/full_process_input.csv')

#errors
match_error = pd.read_csv('/opt/pwdata/katie/csc2.1/matching_error.txt', skiprows=1, names=['ids', 'date', 'exp', 'theta'])
fit_error = pd.read_csv('/opt/pwdata/katie/csc2.1/fitting_error.txt', skiprows=1, names=['ids'])
wav_error = pd.read_csv('/opt/pwdata/katie/csc2.1/wavdetect_error.txt', skiprows=1, names=['ids'])

#other
stats =  pd.read_csv('/opt/pwdata/katie/csc2.1/stats.csv')
compton = pd.read_csv('/opt/pwdata/katie/csc2.1/final_data/final_compton_list.txt', skiprows=1, names=['ids'])
triply_unabsorbed_list = pd.read_csv('/opt/pwdata/katie/csc2.1/final_data/triply_unabsorbed_list.txt', skiprows=1, names=['ids'])

#individual fits
main = pd.read_csv('/opt/pwdata/katie/csc2.1/allinfo_full_withratio.csv')
res = pd.read_csv('/opt/pwdata/katie/csc2.1/allinfo_full_withratio_res.csv')
alt = pd.read_csv('/opt/pwdata/katie/csc2.1/allinfo_full_withratio_alt.csv')

#final lists
final_list=pd.read_csv('/opt/pwdata/katie/csc2.1/data_full.txt', skiprows=1, delimiter='  ',names=['NAME','OBSID','RA', 'DEC', 'Z', 'nH', 'COUNTS'])
final_min_abs = pd.read_csv('/opt/pwdata/katie/csc2.1/final_data/final_info_min_abs_full.csv')
final_full = pd.read_csv('/opt/pwdata/katie/csc2.1/final_data/final_info_full.csv')

#other previous list
final_alt = pd.read_csv('/opt/pwdata/katie/pre_6_3_run/final_data/final_info_full.csv')

#compton thick in all different versions
main_compton = main.loc[main['compton thick']=='Yes']
res_compton = res.loc[res['compton thick']=='Yes']
alt_compton = alt.loc[alt['compton thick']=='Yes']

#unabsorbed and always unabsorbed guys
unabsorbed=final_full.loc[final_full['unabsorbed']==True]
unabsorbed_old=final_alt.loc[final_alt['unabsorbed']==True]

always_unabsorbed=[]

for id, row in unabsorbed.iterrows():
    #find all the instances of this object which passed matching
    obj=row['CXO name']
    obj_df=final_full.loc[final_full['CXO name']==obj]
    
    #always unabsorbed (or ones w/only one observation) will all have the same 'True' value
    if len(set(obj_df['unabsorbed'])) == 1:
        if obj not in always_unabsorbed:
            always_unabsorbed.append(obj)

#compton calcs
compton_actual=final_full.loc[final_full['compton thick']=='Yes']
compton_actual_old=final_alt.loc[final_alt['compton thick']=='True']

always_compton=[]

for id, row in compton_actual.iterrows():
    #find all the instances of this object which passed matching
    obj=row['CXO name']
    obj_df=final_full.loc[final_full['CXO name']==obj]
    
    #always compton (or ones w/only one observation) will all have the same 'True' value
    if len(set(obj_df['compton thick'])) == 1:
        if obj not in always_compton:
            always_compton.append(obj)

#do some absorbed calcs
absorbed=final_full.loc[(final_full['unabsorbed']==False) & (final_full['compton thick']!='Yes')]
absorbed_old=final_alt.loc[(final_alt['unabsorbed']==False) & (final_alt['compton thick']!='True')]

unique_only_absorbed=set(absorbed['CXO name'])-set(compton_actual['CXO name'])-set(unabsorbed['CXO name'])

#doing some maybe compton calcs
compton_maybe=final_full.loc[final_full['compton thick']=='Maybe']

#dealing with all the errors uniqueness
real_ids=[]
for id, row in wav_error.iterrows():
    real_ids.append(row['ids'].split()[0])

wav_error['real ids']=real_ids

real_ids=[]
for id, row in match_error.iterrows():
    real_ids.append(row['ids'].split()[0])

match_error['real ids']=real_ids

real_ids=[]
for id, row in fit_error.iterrows():
    real_ids.append(row['ids'].split()[0])

fit_error['real ids']=real_ids
wav_error=pd.merge(wav_error, final_list, how='left', left_on='real ids', right_on='OBSID')
match_error=pd.merge(match_error, final_list, how='left', left_on='real ids', right_on='OBSID')
fit_error=pd.merge(fit_error, final_list, how='left', left_on='real ids', right_on='OBSID')

passed = set(final_full["CXO name"])
all_dudes=set(input_file['CSC21P_name'])

#trying to deal with the obs-obj discrepancies
passed_obsids = set(final_full['# ObsID'])
all_obsids=set(final_list['OBSID'])

#Printing stuff
print()
print('------ERRORS vs PASS------')
print(f"Input file had {len(input_file)} obsid-object combos")
print(f'Unique attempted guys: {len(all_dudes)}')
print()
print(f"Wavdetect errors: {len(wav_error)}")
print(f'Unique wav_error: {len(set(wav_error["NAME"]))}')
wav_er=set(wav_error["NAME"])-passed
print(f'Unique wav_error that didnt also pass: {len(wav_er)}')
print(wav_er)
print()
print(f"Match region errors: {len(match_error)}")
print(f'Unique match_error: {len(set(match_error["NAME"]))}')
mat_er=set(match_error["NAME"])-passed
print(f'Unique match_error that didnt also pass: {len(mat_er)}')
print()
print(f"Sherpa fitting errors: {len(fit_error)}")
print(f'Unique fit_error: {len(set(fit_error["NAME"]))}')
fit_er=set(fit_error["NAME"])-passed
print(f'Unique fit_error that didnt also pass: {len(fit_er)}')
print()
unpassed_er=mat_er | wav_er | fit_er
print(f'Unique total errors that didnt also pass: {len(unpassed_er)}')
print(f'Errored out using the all - passed method is, which should be same: {len(all_dudes-passed)}')
print(f'Unique guys that passed over all errors onto final_full: {len(passed)}')
print(f'Unpassed any error plus passed should be 717: {len(unpassed_er)+len(passed)}')
print(f'fell through cracks:')
#where did these error out? because they didn't pass, but they also didn't unpass
cracks = all_dudes-passed-unpassed_er
crack_df=input_file.loc[input_file['CSC21P_name'].isin(cracks)]
print(crack_df)
print('These are the 5 objects in the two obsids (5757, 5766) I tracked down that failed wavdetect silently.')
print(f"Any wav_error not in match error? Should be 1: {wav_er - mat_er}")
cracks=cracks | (wav_er - mat_er)
print(f'check if all cracks are not in passed, should be true (6 of them) but maybe not: {cracks-passed}')
print()
print()
print('------STATS------')
print(f"Total absorbed, using False in the final_full: {len(absorbed)}")
print(f"Total absorbed old, using False in the final_full: {len(absorbed_old)}")
print(f"Unique absorbed which aren't ever compton or unabs: {len(unique_only_absorbed)}")
print()
print(f"Compton gguys: {len(compton_actual)}")
print(f"Unique compton guys: {len(compton_actual['CXO name'].unique())}")
print(f"Unique compton old guys: {len(compton_actual_old['CXO name'].unique())}")
print(f'Always compton unique guys: {len(set(always_compton))}')
print()
print(f"there are {len(compton_maybe)} compton maybes total")
print(f"which are {len(set(compton_maybe['CXO name']))} unique objs total")
maybe_abs=set(compton_maybe['CXO name'])-set(unabsorbed['CXO name'])
print(f"{len(maybe_abs)} of them are in the absorbed category")
maybe_unabs=set(compton_maybe['CXO name'])-unique_only_absorbed
print(f"{len(maybe_unabs)} of them are in the min abs category, which added w/above should be unique total")
print(f"so actually 1 is a guy that's in both min abs and abs")
print()
print(f'Total unabsorbed: {len(unabsorbed)}')
print(f'Total unabsorbed old: {len(unabsorbed_old)}')
print(f'Unique guys: {len(unabsorbed["CXO name"].unique())}')
print(f'Unique old guys: {len(unabsorbed_old["CXO name"].unique())}')
print(f'Always unabsrobed unique guys: {len(set(always_unabsorbed))}')
print(f"Triply unabsorbed: {len(triply_unabsorbed_list)}")
print()
print(f"one problem child who is in both unique min abs, and unique compton thick {(set(unabsorbed['CXO name']) & set(compton_actual['CXO name']))}")


print('------NONUNIQUE STATS------')
print(f"total obsids-objs: {len(all_obsids)}")
print(f"passed obsids: {len(passed_obsids)}")
failed_obsids=all_obsids-passed_obsids
print(f"failed obsids {len(failed_obsids)}")
print(f"wav error set of obsids: {len(set(wav_error['OBSID']))}")
print(f"match error set of obsids: {len(set(match_error['OBSID']))}")
print(f"fit error set of obsids: {len(set(fit_error['OBSID']))}")
all_errs=set(wav_error['OBSID'])|set(match_error['OBSID'])|set(fit_error['OBSID'])
print(f"total obsids errored: {len(all_errs)}")
print(f"who are the total obsids errored that aren't in failed_obsids: {len(all_errs-failed_obsids)}")
print(f"they seem to be the fit errors. true if this is also 118: {len(set(fit_error['OBSID'])-failed_obsids)}")
weirdos=failed_obsids-set(wav_error['OBSID'])-set(match_error['OBSID'])
print(f"however that means there's extra failed obsids that Aren't caught by either wav or match. those are: {len(weirdos)}")

print(weirdos)
new_weirdos = weirdos - {'5757','5757b','5757c','5766', '5766b'}
print(f'some of those come from our cracks guys. getting rid of those, we have: {len(new_weirdos)}')
print(new_weirdos)

'''
print(f"Should add up to input file length: {len(wav_error)+len(match_error)+len(fit_error)+len(absorbed)+len(compton)+len(unabsorbed)}")
error_model=final_full.loc[final_full['model']=='ERROR']
print(len(error_model))
errored_when_shouldnt = set(error_model['# ObsID']) - set(fit_error['ids'])
print(len(errored_when_shouldnt))
print(len(final_full))
'''

print(f"main fit={len(final_full.loc[final_full['model']=='main'])}")
print(f"unphys fit={len(final_full.loc[final_full['model']=='main_unphys'])}")
print(f"res fit={len(final_full.loc[final_full['model']=='res'])}")
print(f"alt fit={len(final_full.loc[final_full['model']=='alt'])}")
print(len(final_full))

#bar plot for my presentation
#plt.style.use('dark_background')
plt.figure(figsize=(10,8))
labels=['Errored AGNs', 'Obscured AGNs', 'Compton Thick AGNs', 'Broad Line AGNs \n (Category 6)','Category 4 and 5 AGNs','Uncategorized DR17', 'Category 1, 2, 3 AGNs']
true2s=15
abs=25
ffs=45
sizes=[147+6,421+1, 31, 25, 15+30, 27, 14]
colors=['dimgray','royalblue','orangered', 'green','lime', 'brown','gold']
print(np.sum(sizes))
ls=[]
for i in range(len(labels)):
    percentage = sizes[i]/np.sum(sizes)*100
    label = f'{labels[i]}: \n{sizes[i]} ({percentage:.1f}%)'
    ls.append(label)

plt.figure(figsize=(10,10))

plt.pie(sizes, labels=ls, colors=colors)
plt.savefig(f"/Users/kciurleo/Documents/kciurleo/AGN/plots/newest.pdf", format="pdf")
plt.show(block=False)
print(np.sum(np.array(sizes)))

labels = ['Category 6 AGNs','Category 5 AGNs','Category 4 AGNS','Category 3 AGNs','Category 2 AGNs','Category 1 AGNs','Uncategorized DR17']
sizes = [25, 15, 30, 5, 6, 4, 27]
colors = ['green','limegreen', 'lime','darkgoldenrod','orange','gold','brown']

# Reverse the order
labels = labels[::-1]
sizes = sizes[::-1]
colors = colors[::-1]

print(np.sum(sizes))
ls = []
for i in range(len(labels)):
    percentage = sizes[i]/np.sum(sizes)*100
    label = f'{labels[i]}: \n{sizes[i]} ({percentage:.1f}%)'
    ls.append(label)

plt.figure(figsize=(10,10))
plt.pie(sizes, labels=ls, colors=colors)
plt.savefig(f"/Users/kciurleo/Documents/kciurleo/AGN/plots/optpie.pdf", format="pdf")
plt.show()

print(np.sum(np.array(sizes)))